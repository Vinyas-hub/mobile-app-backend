package org.vinyas;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class LaptopResourceIT extends LaptopResourceTest {
    // Execute the same tests but in packaged mode.
}
